"use strict";(()=>{var e={};e.id=386,e.ids=[386],e.modules={20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},6005:e=>{e.exports=require("node:crypto")},31062:(e,t,r)=>{r.r(t),r.d(t,{originalPathname:()=>m,patchFetch:()=>x,requestAsyncStorage:()=>c,routeModule:()=>u,serverHooks:()=>g,staticGenerationAsyncStorage:()=>d});var s={};r.r(s),r.d(s,{POST:()=>l});var o=r(49303),a=r(88716),n=r(60670),i=r(87070),p=r(2723);async function l(e){try{let{email:t,name:r,message:s}=await e.json();if(!t||!r||!s)return i.NextResponse.json({error:"Please provide all required fields"},{status:400});if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(t))return i.NextResponse.json({error:"Please provide a valid email address"},{status:400});if(s.trim().length<10)return i.NextResponse.json({error:"Message must be at least 10 characters long"},{status:400});try{if(!process.env.RESEND_API_KEY)throw Error("RESEND_API_KEY is not configured");let e=new p.R(process.env.RESEND_API_KEY);return await e.emails.send({from:"HubLab Contact <onboarding@resend.dev>",to:"hublab@outlook.es",replyTo:t,subject:`New Contact Message from ${r}`,html:`
          <div style="font-family: sans-serif; max-width: 600px; margin: 0 auto;">
            <h2 style="color: #111827;">New Contact Form Submission</h2>
            <p>You have received a new message from the HubLab contact form.</p>

            <div style="background: #f3f4f6; padding: 20px; border-radius: 8px; margin: 20px 0;">
              <p style="margin: 8px 0;"><strong>Name:</strong> ${r}</p>
              <p style="margin: 8px 0;"><strong>Email:</strong> ${t}</p>
              <p style="margin: 8px 0;"><strong>Date:</strong> ${new Date().toLocaleString("en-US",{dateStyle:"long",timeStyle:"short"})}</p>
            </div>

            <div style="background: #ffffff; border: 1px solid #e5e7eb; padding: 20px; border-radius: 8px; margin: 20px 0;">
              <p style="margin: 0 0 8px 0;"><strong>Message:</strong></p>
              <p style="color: #374151; line-height: 1.6; white-space: pre-wrap;">${s}</p>
            </div>

            <p style="color: #6b7280; font-size: 14px; margin-top: 20px;">
              You can reply directly to this email to respond to ${r}.
            </p>
          </div>
        `}),i.NextResponse.json({success:!0,message:"Message sent successfully"},{status:200})}catch(e){return console.error("Email sending error:",e),i.NextResponse.json({error:"Failed to send message. Please try again later."},{status:500})}}catch(e){return console.error("Contact API error:",e),i.NextResponse.json({error:"An unexpected error occurred"},{status:500})}}let u=new o.AppRouteRouteModule({definition:{kind:a.x.APP_ROUTE,page:"/api/contact/route",pathname:"/api/contact",filename:"route",bundlePath:"app/api/contact/route"},resolvedPagePath:"/Users/c/hublab/app/api/contact/route.ts",nextConfigOutput:"standalone",userland:s}),{requestAsyncStorage:c,staticGenerationAsyncStorage:d,serverHooks:g}=u,m="/api/contact/route";function x(){return(0,n.patchFetch)({serverHooks:g,staticGenerationAsyncStorage:d})}}};var t=require("../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),s=t.X(0,[276,972,723],()=>r(31062));module.exports=s})();